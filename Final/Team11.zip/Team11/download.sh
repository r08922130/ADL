wget https://www.dropbox.com/sh/7nil30ul8zj1xna/AAD7iZnWBh9whINdueO_jMSfa?dl=1 -O ckpt.zip
unzip ckpt.zip -d ckpt